Place the contents of the GameData folder into your GameData folder of KSP.

To use, you must have RasterPropMoniter Installed (v.16, I don't know if .17 will work) and Hyomoto's mod of RPM installed.

Right now, my modification only works in Hyomoto's cockpits.

To use, press the "A" button in the cockpit until the Horizontal Situation Indicator shows up. To change Runways use the buttons below the "Prev" and "Next" labels.

To change glideslopes, Press the up and down arrows on the right of the screen.

Use of this development version is restricted only to evaluation of the work. You may not share, sell, transmit, or otherwise provide this work to another person, either directly or indirectly, nor are you permitted to upload the work to a publicly accessible location.