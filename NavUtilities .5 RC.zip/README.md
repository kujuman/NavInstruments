NavInstruments
==============
This mod for KSP is intended to provide navigation instruments in both IVA and external views
